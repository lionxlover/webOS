/* Synthwave — Web Audio engine: four synthesized voices, no samples. */
(function () {
  'use strict';

  class SynthAudio {
    constructor() {
      this.ctx = null;
      this.master = null;
    }

    ensure() {
      if (!this.ctx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return false;
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = 0.85;
        this.master.connect(this.ctx.destination);
      }
      if (this.ctx.state === 'suspended') this.ctx.resume();
      return true;
    }

    get time() { return this.ctx ? this.ctx.currentTime : 0; }

    env(t, d, peak) {
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(peak, t + 0.004);
      g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      return g;
    }

    kick(t) {
      const osc = this.ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(150, t);
      osc.frequency.exponentialRampToValueAtTime(42, t + 0.12);
      const g = this.env(t, 0.24, 0.95);
      osc.connect(g).connect(this.master);
      osc.start(t); osc.stop(t + 0.26);
    }

    snare(t) {
      const len = 0.16;
      const buf = this.ctx.createBuffer(1, this.ctx.sampleRate * len, this.ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
      const src = this.ctx.createBufferSource();
      src.buffer = buf;
      const bp = this.ctx.createBiquadFilter();
      bp.type = 'bandpass'; bp.frequency.value = 1800; bp.Q.value = 0.8;
      const g = this.env(t, len, 0.5);
      src.connect(bp).connect(g).connect(this.master);
      src.start(t);
      // body tone
      const osc = this.ctx.createOscillator();
      osc.type = 'triangle'; osc.frequency.setValueAtTime(190, t);
      const g2 = this.env(t, 0.09, 0.35);
      osc.connect(g2).connect(this.master);
      osc.start(t); osc.stop(t + 0.1);
    }

    hat(t, open) {
      const len = open ? 0.22 : 0.05;
      const buf = this.ctx.createBuffer(1, this.ctx.sampleRate * len, this.ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / d.length, 2);
      const src = this.ctx.createBufferSource();
      src.buffer = buf;
      const hp = this.ctx.createBiquadFilter();
      hp.type = 'highpass'; hp.frequency.value = 7000;
      const g = this.env(t, len, 0.22);
      src.connect(hp).connect(g).connect(this.master);
      src.start(t);
    }

    bass(t, step) {
      // sliding acid line — pattern of semitone offsets
      const semis = [0, 0, 3, 0, 5, 3, 0, -2, 0, 0, 3, 7, 5, 3, 0, -2];
      const f = 55 * Math.pow(2, semis[step % 16] / 12);
      const osc = this.ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, t);
      osc.frequency.exponentialRampToValueAtTime(f * 1.06, t + 0.02);
      const lp = this.ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.setValueAtTime(380, t);
      lp.frequency.exponentialRampToValueAtTime(1600, t + 0.08);
      lp.frequency.exponentialRampToValueAtTime(300, t + 0.22);
      lp.Q.value = 9;
      const g = this.env(t, 0.26, 0.42);
      osc.connect(lp).connect(g).connect(this.master);
      osc.start(t); osc.stop(t + 0.3);
    }

    play(track, t, step) {
      if (!this.ensure()) return;
      try {
        if (track === 0) this.kick(t);
        else if (track === 1) this.snare(t);
        else if (track === 2) this.hat(t, step % 4 === 2);
        else this.bass(t, step);
      } catch (e) { /* ignore voice errors */ }
    }
  }

  window.SynthAudio = SynthAudio;
})();
