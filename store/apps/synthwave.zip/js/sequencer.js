/* Synthwave — sequencer grid, scheduler and UI wiring. */
(function () {
  'use strict';

  const STEPS = 16;
  const TRACKS = [
    { name: 'Kick', glyph: '🥁', cls: '' },
    { name: 'Snare', glyph: '🪘', cls: 'row-amber' },
    { name: 'Hat', glyph: '🎩', cls: 'row-cyan' },
    { name: 'Bass', glyph: '🎸', cls: 'row-violet' },
  ];

  const audio = new SynthAudio();
  const gridEl = document.getElementById('grid');
  const playBtn = document.getElementById('playBtn');
  const clearBtn = document.getElementById('clearBtn');
  const presetSel = document.getElementById('presetSel');
  const bpmSlider = document.getElementById('bpmSlider');
  const bpmVal = document.getElementById('bpmVal');
  const swingSlider = document.getElementById('swingSlider');
  const swingVal = document.getElementById('swingVal');
  const stepTag = document.getElementById('stepTag');

  // pattern[track][step] — seeded with a starter groove
  const pattern = [
    [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
    [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0],
    [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0],
    [1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 1],
  ];

  let playing = false;
  let current = -1;
  let lookahead = null;
  let nextTime = 0;
  let step = 0;
  let cells = [];

  function buildGrid() {
    gridEl.innerHTML = '';
    cells = TRACKS.map(() => []);

    const beats = document.createElement('div');
    beats.className = 'rowline beats';
    beats.appendChild(document.createElement('span'));
    for (let s = 0; s < STEPS; s++) {
      const b = document.createElement('span');
      b.textContent = String(Math.floor(s / 4) + 1);
      if (s % 4 === 0) b.classList.add('q');
      beats.appendChild(b);
    }
    gridEl.appendChild(beats);

    TRACKS.forEach((tr, ti) => {
      const line = document.createElement('div');
      line.className = 'rowline ' + tr.cls;
      const label = document.createElement('div');
      label.className = 'trk';
      label.innerHTML = tr.name + ' <i>' + tr.glyph + '</i>';
      line.appendChild(label);
      for (let s = 0; s < STEPS; s++) {
        const c = document.createElement('div');
        c.className = 'cell' + (s % 4 === 0 ? ' q' : '') + (pattern[ti][s] ? ' on' : '');
        c.addEventListener('click', () => {
          pattern[ti][s] = pattern[ti][s] ? 0 : 1;
          c.classList.toggle('on', !!pattern[ti][s]);
          if (pattern[ti][s] && !playing) audio.play(ti, audio.time, s); // instant preview
        });
        cells[ti].push(c);
        line.appendChild(c);
      }
      gridEl.appendChild(line);
    });
  }

  function paintPlayhead(s) {
    cells.forEach((row) => row.forEach((c, i) => c.classList.toggle('now', i === s)));
    stepTag.textContent = playing ? 'step ' + String(s + 1).padStart(2, '0') + ' / 16 · ' + bpmSlider.value + ' bpm' : 'stopped';
  }

  function schedule() {
    const bpm = Number(bpmSlider.value);
    const swing = Number(swingSlider.value) / 100;
    const stepDur = 60 / bpm / 4; // sixteenth
    while (nextTime < audio.time + 0.12) {
      const s = step % STEPS;
      const t = nextTime + (s % 2 === 1 ? stepDur * swing : 0);
      for (let ti = 0; ti < TRACKS.length; ti++) {
        if (pattern[ti][s]) audio.play(ti, t, s);
      }
      const at = Math.max(0, (nextTime - audio.time) * 1000);
      setTimeout(() => { if (playing) { current = s; paintPlayhead(s); } }, at);
      nextTime += stepDur;
      step++;
    }
  }

  function play() {
    if (!audio.ensure()) return;
    playing = true;
    step = 0;
    nextTime = audio.time + 0.06;
    playBtn.textContent = '⏸ Stop';
    playBtn.classList.add('on');
    lookahead = setInterval(schedule, 30);
    schedule();
    try { parent.postMessage({ lx: 'title', value: 'Synthwave — playing' }, '*'); } catch (e) {}
  }

  function stop() {
    playing = false;
    clearInterval(lookahead);
    playBtn.textContent = '▶ Play';
    playBtn.classList.remove('on');
    current = -1;
    paintPlayhead(-1);
    try { parent.postMessage({ lx: 'title', value: 'Synthwave Sequencer' }, '*'); } catch (e) {}
  }

  playBtn.addEventListener('click', () => (playing ? stop() : play()));
  window.addEventListener('keydown', (e) => {
    if (e.code === 'Space') { e.preventDefault(); playing ? stop() : play(); }
  });

  clearBtn.addEventListener('click', () => {
    for (let t = 0; t < TRACKS.length; t++) for (let s = 0; s < STEPS; s++) pattern[t][s] = 0;
    gridEl.querySelectorAll('.cell.on').forEach((c) => c.classList.remove('on'));
  });

  presetSel.addEventListener('change', () => {
    const v = presetSel.value;
    if (!v) return;
    const P = {
      four: [[1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1], [1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0]],
      break: [[1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0], [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1],
              [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0], [1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0]],
      acid: [[1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0], [1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1]],
    }[v];
    for (let t = 0; t < TRACKS.length; t++) for (let s = 0; s < STEPS; s++) pattern[t][s] = P[t][s];
    gridEl.querySelectorAll('.rowline:not(.beats)').forEach((line, ti) => {
      line.querySelectorAll('.cell').forEach((c, s) => c.classList.toggle('on', !!pattern[ti][s]));
    });
    if (!playing) play();
    presetSel.value = '';
  });

  bpmSlider.addEventListener('input', () => { bpmVal.textContent = bpmSlider.value; });
  swingSlider.addEventListener('input', () => { swingVal.textContent = swingSlider.value + '%'; });

  buildGrid();
  paintPlayhead(-1);
})();
