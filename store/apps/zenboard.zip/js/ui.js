/* Zenboard — UI layer: renders lanes & cards, wires events. */
(function () {
  'use strict';

  const store = new ZenStore();
  const board = document.getElementById('board');
  const counters = document.getElementById('counters');
  const quick = document.getElementById('quickInput');

  const META = {
    todo: { title: 'To do', glyph: '🌱' },
    doing: { title: 'Doing', glyph: '⚡' },
    done: { title: 'Done', glyph: '🍀' },
  };

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  function cardOf(task, lane) {
    const card = el('div', 'card' + (task.high ? ' high' : ''), task.text);
    card.title = 'click to move forward';
    card.addEventListener('click', (e) => {
      if (e.target.classList.contains('back')) return;
      store.move(task.id, 1);
      draw();
    });
    if (lane !== 'todo') {
      const back = el('button', 'back', '↩');
      back.title = 'move back';
      back.addEventListener('click', (e) => {
        e.stopPropagation();
        store.move(task.id, -1);
        draw();
      });
      card.appendChild(back);
    }
    if (lane === 'done') {
      card.addEventListener('dblclick', () => { store.remove(task.id); draw(); });
    }
    return card;
  }

  function draw() {
    board.innerHTML = '';
    ZenStore.LANES.forEach((lane) => {
      const laneEl = el('section', 'lane ' + lane);
      const head = el('div', 'lane-head');
      head.appendChild(el('span', 'dot'));
      head.appendChild(el('span', null, META[lane].title));
      const list = store.byLane(lane);
      head.appendChild(el('span', 'n', String(list.length)));
      laneEl.appendChild(head);

      const cards = el('div', 'lane-cards');
      if (!list.length) {
        const empty = el('div', 'empty');
        const g = el('span', 'glyph', META[lane].glyph);
        empty.appendChild(g);
        empty.appendChild(document.createTextNode(listEmpty(lane)));
        cards.appendChild(empty);
      } else {
        list.forEach((t) => cards.appendChild(cardOf(t, lane)));
      }
      laneEl.appendChild(cards);
      board.appendChild(laneEl);
    });

    const s = store.stats();
    counters.innerHTML = '';
    counters.appendChild(counterEl(s.todo + s.doing, 'open'));
    counters.appendChild(counterEl(s.doing, 'in progress'));
    counters.appendChild(counterEl(s.done, 'finished ✓'));
    try { parent.postMessage({ lx: 'title', value: 'Zenboard — ' + s.done + ' done' }, '*'); } catch (e) {}
  }

  function counterEl(n, label) {
    const wrap = el('span', 'counter');
    const b = el('b', null, String(n));
    wrap.appendChild(b);
    wrap.appendChild(document.createTextNode(' ' + label));
    return wrap;
  }

  function listEmpty(lane) {
    if (lane === 'todo') return 'nothing queued — add a task above';
    if (lane === 'doing') return 'pick something from To do';
    return 'finish something to fill this lane';
  }

  quick.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const t = store.add(quick.value);
      if (t) { quick.value = ''; draw(); }
    }
  });

  document.getElementById('clearBtn').addEventListener('click', () => {
    const n = store.clearDone();
    if (n) flash('Cleared ' + n + ' finished task' + (n > 1 ? 's' : '') + ' ✨');
    draw();
  });

  let flashTimer;
  function flash(msg) {
    let f = document.querySelector('.flash');
    if (!f) {
      f = el('div', 'flash');
      f.style.cssText = 'position:fixed;left:50%;bottom:22px;transform:translateX(-50%);background:#2b2440;color:#fff;font-size:12.5px;font-weight:600;padding:9px 18px;border-radius:999px;box-shadow:0 8px 26px rgba(40,20,80,.35);z-index:9;transition:opacity .4s ease;opacity:0';
      document.body.appendChild(f);
    }
    f.textContent = msg;
    f.style.opacity = '1';
    clearTimeout(flashTimer);
    flashTimer = setTimeout(() => { f.style.opacity = '0'; }, 1800);
  }

  draw();
})();
