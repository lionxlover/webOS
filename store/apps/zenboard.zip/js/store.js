/* Zenboard — data store: tasks, persistence and stats (its own file). */
(function () {
  'use strict';

  const LANES = ['todo', 'doing', 'done'];

  class Store {
    constructor() {
      this.tasks = [];
      this.load();
    }

    /* sandboxed apps have no localStorage — try it, fall back to memory */
    load() {
      try {
        const raw = localStorage.getItem('zenboard.tasks');
        if (raw) this.tasks = JSON.parse(raw);
      } catch (e) { /* sandbox or corrupt data — start fresh */ }
      if (!Array.isArray(this.tasks) || !this.tasks.length) this.seed();
    }

    save() {
      try { localStorage.setItem('zenboard.tasks', JSON.stringify(this.tasks)); } catch (e) {}
    }

    seed() {
      this.tasks = [
        { id: uid(), text: 'Read the Leonux store SPEC', lane: 'done', high: false, t: Date.now() - 9e6 },
        { id: uid(), text: 'Ship the multi-file zip app', lane: 'doing', high: true, t: Date.now() - 5e6 },
        { id: uid(), text: 'Paste your repo link in App Store → Sources', lane: 'todo', high: false, t: Date.now() - 2e6 },
        { id: uid(), text: 'Publish your own appstore on GitHub', lane: 'todo', high: false, t: Date.now() - 1e6 },
      ];
    }

    add(text) {
      const high = false;
      const clean = String(text || '').trim();
      if (!clean) return null;
      const isHigh = clean.charAt(0) === '!';
      const task = { id: uid(), text: isHigh ? clean.slice(1).trim() : clean, lane: 'todo', high: isHigh || high, t: Date.now() };
      this.tasks.unshift(task);
      this.save();
      return task;
    }

    move(id, dir) {
      const t = this.tasks.find((x) => x.id === id);
      if (!t) return;
      const i = LANES.indexOf(t.lane);
      const next = i + dir;
      if (next < 0 || next >= LANES.length) return;
      t.lane = LANES[next];
      t.t = Date.now();
      if (t.lane === 'done') this.celebrate = (this.celebrate || 0) + 1;
      this.save();
    }

    remove(id) {
      this.tasks = this.tasks.filter((t) => t.id !== id);
      this.save();
    }

    clearDone() {
      const n = this.tasks.filter((t) => t.lane === 'done').length;
      this.tasks = this.tasks.filter((t) => t.lane !== 'done');
      this.save();
      return n;
    }

    byLane(lane) { return this.tasks.filter((t) => t.lane === lane).sort((a, b) => b.t - a.t); }
    stats() {
      const s = { todo: 0, doing: 0, done: 0, total: this.tasks.length };
      this.tasks.forEach((t) => { s[t.lane]++; });
      return s;
    }
  }

  function uid() { return Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-3); }

  Store.LANES = LANES;
  window.ZenStore = Store;
})();
