/* Star Painter — canvas controller: pointer input, brush state, undo, export. */
(function () {
  'use strict';

  const canvas = document.getElementById('paper');
  const ctx = canvas.getContext('2d');
  const foot = document.getElementById('foot');
  const colorPick = document.getElementById('colorPick');
  const swatch = document.getElementById('swatch');
  const sizeSlider = document.getElementById('sizeSlider');
  const sizeVal = document.getElementById('sizeVal');
  const darkBg = document.getElementById('darkBg');
  const brushesBox = document.getElementById('brushes');

  const NAMES = Object.keys(StarBrushes).filter((k) => StarBrushes[k].stroke);
  let brushKey = NAMES[0];
  let drawing = false;
  let last = null;
  let t = 0; // stroke clock for the rainbow brush
  const snapshots = [];
  const MAX_UNDO = 12;

  function resize() {
    const r = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    const snap = ctx.getImageData(0, 0, canvas.width || 1, canvas.height || 1);
    canvas.width = Math.max(1, Math.round(r.width * dpr));
    canvas.height = Math.max(1, Math.round(r.height * dpr));
    ctx.putImageData(snap, 0, 0);
  }

  function pos(e) {
    const r = canvas.getBoundingClientRect();
    const p = e.touches ? e.touches[0] : e;
    return { x: (p.clientX - r.left) * (canvas.width / r.width), y: (p.clientY - r.top) * (canvas.height / r.height) };
  }

  function snapshot() {
    try {
      snapshots.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
      if (snapshots.length > MAX_UNDO) snapshots.shift();
    } catch (e) { /* canvas too large — skip undo */ }
  }

  /* ---- brush picker ---- */
  NAMES.forEach((k, i) => {
    const b = StarBrushes[k];
    const btn = document.createElement('button');
    btn.className = 'bbtn' + (i === 0 ? ' on' : '');
    btn.innerHTML = '<span class="em">' + b.em + '</span>' + b.label;
    btn.addEventListener('click', () => {
      brushKey = k;
      brushesBox.querySelectorAll('.bbtn').forEach((x) => x.classList.remove('on'));
      btn.classList.add('on');
      foot.textContent = b.label.toLowerCase() + ' brush — draw with your mouse or finger';
    });
    brushesBox.appendChild(btn);
  });

  /* ---- pointer input ---- */
  function start(e) {
    e.preventDefault();
    snapshot();
    drawing = true;
    last = pos(e);
    dab(last);
  }
  function move(e) {
    if (!drawing) return;
    e.preventDefault();
    const p = pos(e);
    const opts = { color: colorPick.value, size: Number(sizeSlider.value) * (canvas.width / 600) * 1.6, t: t += 0.6 };
    StarBrushes[brushKey].stroke(ctx, last, p, opts);
    last = p;
  }
  function dab(p) {
    const opts = { color: colorPick.value, size: Number(sizeSlider.value) * (canvas.width / 600) * 1.6, t: t += 0.6 };
    StarBrushes[brushKey].stroke(ctx, p, { x: p.x + 0.01, y: p.y }, opts);
  }
  function end() { drawing = false; last = null; }

  canvas.addEventListener('mousedown', start);
  window.addEventListener('mousemove', move);
  window.addEventListener('mouseup', end);
  canvas.addEventListener('touchstart', start, { passive: false });
  canvas.addEventListener('touchmove', move, { passive: false });
  canvas.addEventListener('touchend', end);

  /* ---- controls ---- */
  colorPick.addEventListener('input', () => { swatch.style.background = colorPick.value; });
  sizeSlider.addEventListener('input', () => { sizeVal.textContent = sizeSlider.value; });
  darkBg.addEventListener('change', () => canvas.classList.toggle('light', !darkBg.checked));

  document.getElementById('undoBtn').addEventListener('click', () => {
    const s = snapshots.pop();
    if (s) ctx.putImageData(s, 0, 0);
  });

  document.getElementById('clearBtn').addEventListener('click', () => {
    snapshot();
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  });

  document.getElementById('saveBtn').addEventListener('click', () => {
    // composite onto the chosen background colour, then download
    const out = document.createElement('canvas');
    out.width = canvas.width; out.height = canvas.height;
    const o = out.getContext('2d');
    o.fillStyle = darkBg.checked ? '#0e0b13' : '#f7f2e9';
    o.fillRect(0, 0, out.width, out.height);
    o.drawImage(canvas, 0, 0);
    const a = document.createElement('a');
    a.href = out.toDataURL('image/png');
    a.download = 'starpainter-' + Date.now() + '.png';
    document.body.appendChild(a);
    a.click();
    a.remove();
  });

  new ResizeObserver(resize).observe(canvas);
  resize();
})();
