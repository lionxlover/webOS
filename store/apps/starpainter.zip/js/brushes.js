/* Star Painter — brush engines. Each brush is a pure drawing strategy
   that only sees (ctx, from, to, options); no DOM wiring here. */
(function () {
  'use strict';

  function hexToRgb(hex) {
    const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex || '#f6c177');
    return m ? [parseInt(m[1], 16), parseInt(m[2], 16), parseInt(m[3], 16)] : [246, 193, 119];
  }
  function rgba(hex, a) {
    const c = hexToRgb(hex);
    return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')';
  }
  function dist(a, b) { return Math.hypot(b.x - a.x, b.y - a.y); }

  const brushes = {

    /* neon glow — layered soft strokes that leave light trails */
    neon: {
      label: 'Neon glow', em: '✨',
      stroke(ctx, from, to, o) {
        const d = Math.max(2, dist(from, to));
        ctx.lineCap = 'round';
        // wide faint halo
        ctx.strokeStyle = rgba(o.color, 0.10);
        ctx.lineWidth = o.size * 2.4;
        ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y); ctx.stroke();
        // mid glow
        ctx.strokeStyle = rgba(o.color, 0.32);
        ctx.lineWidth = o.size * 1.3;
        ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y); ctx.stroke();
        // bright core
        ctx.strokeStyle = rgba('#ffffff', 0.5);
        ctx.lineWidth = Math.max(1, o.size * 0.4);
        ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y); ctx.stroke();
        if (d > 90) { /* long fast strokes stay smooth */ }
      },
    },

    /* rainbow — cycles the hue wheel as you draw */
    rainbow: {
      label: 'Rainbow', em: '🌈',
      stroke(ctx, from, to, o) {
        const hue = (o.t * 6) % 360;
        ctx.lineCap = 'round';
        ctx.strokeStyle = 'hsla(' + hue + ',85%,62%,.9)';
        ctx.lineWidth = o.size;
        ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y); ctx.stroke();
        ctx.strokeStyle = 'hsla(' + ((hue + 40) % 360) + ',85%,70%,.35)';
        ctx.lineWidth = o.size * 1.9;
        ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y); ctx.stroke();
      },
    },

    /* star scatter — particles flung along the stroke */
    stars: {
      label: 'Star scatter', em: '🌟',
      stroke(ctx, from, to, o) {
        const d = dist(from, to);
        const n = Math.max(1, Math.round(d / 6) + 1);
        for (let i = 0; i < n; i++) {
          const t = n === 1 ? 1 : i / (n - 1);
          const x = from.x + (to.x - from.x) * t + (Math.random() - 0.5) * o.size * 1.6;
          const y = from.y + (to.y - from.y) * t + (Math.random() - 0.5) * o.size * 1.6;
          const r = Math.random() * o.size * 0.4 + o.size * 0.12;
          ctx.fillStyle = rgba(Math.random() < 0.25 ? '#ffffff' : o.color, 0.35 + Math.random() * 0.6);
          star(ctx, x, y, r * 2.2, r, 5);
        }
      },
    },
  };

  function star(ctx, cx, cy, outer, inner, points) {
    ctx.beginPath();
    for (let i = 0; i < points * 2; i++) {
      const r = i % 2 === 0 ? outer : inner;
      const a = (i * Math.PI) / points - Math.PI / 2;
      const x = cx + Math.cos(a) * r;
      const y = cy + Math.sin(a) * r;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
  }

  brushes.neon.rgba = rgba; // shared helper for canvas.js
  window.StarBrushes = brushes;
})();
