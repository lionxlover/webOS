/* Neon Snake — renderer & game loop. Wires the engine + input together. */
(function () {
  'use strict';

  const canvas = document.getElementById('board');
  const ctx = canvas.getContext('2d');
  const GRID = SnakeEngine.GRID;
  const CELL = canvas.width / GRID;

  const engine = new SnakeEngine();
  const ui = {
    score: document.getElementById('score'),
    best: document.getElementById('best'),
    len: document.getElementById('lenTag'),
    speed: document.getElementById('speedTag'),
    overlay: document.getElementById('overlay'),
    panel: document.getElementById('panel'),
    msg: document.getElementById('msg'),
    startBtn: document.getElementById('startBtn'),
  };

  // sandboxed iframes have no localStorage — remember the best score in memory
  let best = 0;
  try { best = Number(localStorage.getItem('neonsnake.best')) || 0; } catch (e) {}
  ui.best.textContent = best;

  new SnakeInput((x, y) => engine.turn(x, y)); // eslint-disable-line no-new

  /* ---- drawing ---- */
  function draw(t) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // subtle grid
    ctx.strokeStyle = 'rgba(126,231,135,.055)';
    ctx.lineWidth = 1;
    for (let i = 1; i < GRID; i++) {
      ctx.beginPath(); ctx.moveTo(i * CELL, 0); ctx.lineTo(i * CELL, canvas.height); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, i * CELL); ctx.lineTo(canvas.width, i * CELL); ctx.stroke();
    }

    // food — pulsing orb
    if (engine.food) {
      const pulse = 1 + Math.sin(t / 180) * 0.14;
      const fx = engine.food.x * CELL + CELL / 2;
      const fy = engine.food.y * CELL + CELL / 2;
      const glow = ctx.createRadialGradient(fx, fy, 1, fx, fy, CELL * 1.1 * pulse);
      glow.addColorStop(0, 'rgba(246,193,119,.95)');
      glow.addColorStop(.45, 'rgba(246,193,119,.35)');
      glow.addColorStop(1, 'rgba(246,193,119,0)');
      ctx.fillStyle = glow;
      ctx.fillRect(fx - CELL * 1.4, fy - CELL * 1.4, CELL * 2.8, CELL * 2.8);
    }

    // snake — head first, fading neon tail
    const n = engine.snake.length;
    for (let i = n - 1; i >= 0; i--) {
      const s = engine.snake[i];
      const fade = 1 - (i / Math.max(n, 10)) * 0.55;
      const pad = i === 0 ? 1.5 : 2.5 + (i / Math.max(n, 8)) * 1.2;
      const r = i === 0 ? 7 : 5;
      ctx.fillStyle = engine.alive
        ? 'rgba(126,231,135,' + (0.92 * fade).toFixed(3) + ')'
        : 'rgba(242,139,130,' + (0.85 * fade).toFixed(3) + ')';
      ctx.shadowColor = engine.alive ? 'rgba(126,231,135,.8)' : 'rgba(242,139,130,.7)';
      ctx.shadowBlur = i === 0 ? 16 : 8;
      roundRect(s.x * CELL + pad, s.y * CELL + pad, CELL - pad * 2, CELL - pad * 2, r);
      ctx.fill();
    }
    ctx.shadowBlur = 0;

    // eyes on the head
    if (n) {
      const h = engine.snake[0];
      const cx = h.x * CELL + CELL / 2, cy = h.y * CELL + CELL / 2;
      ctx.fillStyle = '#08130c';
      const ox = engine.dir.x * 3, oy = engine.dir.y * 3;
      const px = engine.dir.x === 0 ? 3.5 : 0, py = engine.dir.y === 0 ? 3.5 : 0;
      [[-1, 1]].forEach(([s]) => {
        circle(cx + ox + px * s, cy + oy + py * s, 1.7);
        circle(cx + ox - px * s, cy + oy - py * s, 1.7);
      });
    }
  }

  function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }
  function circle(x, y, r) { ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); }

  /* ---- loop ---- */
  let tick = 0, raf;
  function loop(t) {
    raf = requestAnimationFrame(loop);
    if (engine.alive && ++tick % engine.ticksPerMove === 0) {
      const what = engine.step();
      if (what !== 'moved') paintHud();
      if (what === 'died') die();
    }
    draw(t);
  }

  function paintHud() {
    ui.score.textContent = engine.score;
    ui.len.textContent = 'length ' + engine.snake.length;
    ui.speed.textContent = 'speed ' + engine.speed.toFixed(1) + '×';
    try { parent.postMessage({ lx: 'title', value: 'Neon Snake — ' + engine.score + ' pts' }, '*'); } catch (e) {}
  }

  function die() {
    if (engine.score > best) {
      best = engine.score;
      ui.best.textContent = best;
      try { localStorage.setItem('neonsnake.best', String(best)); } catch (e) {}
    }
    ui.msg.innerHTML = 'You scored <b>' + engine.score + '</b> with a length of <b>' + engine.snake.length + '</b>.<br>Arrows / WASD to steer · swipe on touch.';
    ui.panel.querySelector('h1').textContent = 'Game Over';
    ui.startBtn.textContent = 'Play again';
    ui.overlay.classList.remove('hidden');
    try { parent.postMessage({ lx: 'title', value: 'Neon Snake' }, '*'); } catch (e) {}
  }

  ui.startBtn.addEventListener('click', () => {
    engine.reset();
    engine.alive = true;
    ui.overlay.classList.add('hidden');
    ui.panel.querySelector('h1').textContent = 'Neon Snake';
    paintHud();
  });

  // render the idle board behind the intro overlay
  engine.alive = false;
  paintHud();
  raf = requestAnimationFrame(loop);
})();
