/* Neon Snake — game engine (pure logic, zero DOM).
   Separate file on purpose: this app demonstrates the multi-file zip format. */
(function () {
  'use strict';

  const GRID = 20; // 20×20 cells

  class SnakeEngine {
    constructor() {
      this.reset();
    }

    reset() {
      this.snake = [{ x: 10, y: 10 }, { x: 9, y: 10 }, { x: 8, y: 10 }];
      this.dir = { x: 1, y: 0 };
      this.queue = [];          // buffered direction changes
      this.food = null;
      this.score = 0;
      this.alive = false;
      this.moveCount = 0;
      this.ticksPerMove = 7;    // lower = faster
      this.spawnFood();
    }

    get speed() { return +(7 / this.ticksPerMove).toFixed(2); }

    turn(nx, ny) {
      const last = this.queue.length ? this.queue[this.queue.length - 1] : this.dir;
      // ignore no-ops and 180° reversals
      if (last.x === -nx && last.y === -ny) return;
      if (last.x === nx && last.y === ny) return;
      if (this.queue.length < 3) this.queue.push({ x: nx, y: ny });
    }

    spawnFood() {
      const free = [];
      for (let y = 0; y < GRID; y++) {
        for (let x = 0; x < GRID; x++) {
          if (!this.snake.some((s) => s.x === x && s.y === y)) free.push({ x, y });
        }
      }
      this.food = free.length ? free[Math.floor(Math.random() * free.length)] : null;
    }

    /* one discrete game step; returns what happened */
    step() {
      if (!this.alive) return 'dead';
      if (this.queue.length) this.dir = this.queue.shift();

      const head = { x: this.snake[0].x + this.dir.x, y: this.snake[0].y + this.dir.y };

      // wall or self collision
      if (head.x < 0 || head.y < 0 || head.x >= GRID || head.y >= GRID ||
          this.snake.some((s) => s.x === head.x && s.y === head.y)) {
        this.alive = false;
        return 'died';
      }

      this.snake.unshift(head);
      this.moveCount++;

      if (this.food && head.x === this.food.x && head.y === this.food.y) {
        this.score += 10;
        this.spawnFood();
        // every 3 orbs, speed up
        if (this.score % 30 === 0 && this.ticksPerMove > 3) this.ticksPerMove--;
        return 'ate';
      }
      this.snake.pop();
      return 'moved';
    }
  }

  SnakeEngine.GRID = GRID;
  window.SnakeEngine = SnakeEngine;
})();
