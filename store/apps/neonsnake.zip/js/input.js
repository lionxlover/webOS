/* Neon Snake — input controller: keyboard + touch swipe, its own file. */
(function () {
  'use strict';

  class Input {
    constructor(onTurn) {
      this.onTurn = onTurn;
      this.touch = null;
      window.addEventListener('keydown', (e) => this.key(e));
      window.addEventListener('touchstart', (e) => {
        this.touch = e.touches[0] ? { x: e.touches[0].clientX, y: e.touches[0].clientY } : null;
      }, { passive: true });
      window.addEventListener('touchend', (e) => {
        if (!this.touch || !e.changedTouches[0]) return;
        const dx = e.changedTouches[0].clientX - this.touch.x;
        const dy = e.changedTouches[0].clientY - this.touch.y;
        this.touch = null;
        if (Math.abs(dx) < 18 && Math.abs(dy) < 18) return; // tap, not swipe
        if (Math.abs(dx) > Math.abs(dy)) this.onTurn(dx > 0 ? 1 : -1, 0);
        else this.onTurn(0, dy > 0 ? 1 : -1);
      }, { passive: true });
    }

    key(e) {
      const map = {
        ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0],
        w: [0, -1], s: [0, 1], a: [-1, 0], d: [1, 0],
        W: [0, -1], S: [0, 1], A: [-1, 0], D: [1, 0],
      };
      const m = map[e.key];
      if (m) {
        e.preventDefault();
        this.onTurn(m[0], m[1]);
      }
    }
  }

  window.SnakeInput = Input;
})();
